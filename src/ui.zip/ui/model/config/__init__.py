"""Configuration data and UI schemas for the UI model layer."""

